package http://ns.electronichealth.net.au/ci/fhir/ImplementationGuide/implementationguide-medicare-records;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class ConsentAustralianOrganDonorRegister {

}
