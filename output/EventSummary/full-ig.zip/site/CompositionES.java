package http://ns.electronichealth.net.au/ci/fhir/3.0/ImplementationGuide/implementationguide-eventsummary-1;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class CompositionES {

}
