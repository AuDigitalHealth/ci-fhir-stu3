package http://ns.electronichealth.net.au/ci/fhir/3.0/ImplementationGuide/implementationguide-personalhealthrecords-1;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class CompositionDocHeaderCEI {

}
